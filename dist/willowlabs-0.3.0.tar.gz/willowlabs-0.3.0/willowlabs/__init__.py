# Copyright 2020 Willow Labs AS. All rights reserved.
from willowlabs.company_information.client import CompanyInformationClient

__version__ = "0.3.0"
