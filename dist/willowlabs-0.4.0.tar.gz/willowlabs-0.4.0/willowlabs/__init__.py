# Copyright 2020 Willow Labs AS. All rights reserved.

__version__ = "0.4.0"
